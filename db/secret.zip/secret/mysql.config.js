/*mysql配置文件*/
const mysqlConfig = {
    database: 'wpzfm',
    user: 'root',
    password: '',
    host: '47.96.162.249',
    port: 3306
}

module.exports = mysqlConfig
