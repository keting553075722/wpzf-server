/*mysql配置文件*/
const mysqlConfig = {
  'connectionLimit': 10,
  database: 'wpzfm',
  user: 'root',
  password: 'telecarto',
  host: '47.96.162.249',
  port: 3306
}

module.exports = mysqlConfig
